# -*- coding: utf-8 -*-
"""
Created on Sat Nov 12 00:34:13 2016

@author: Manuel
"""

# see https://gist.github.com/kljensen/5452382
from sklearn.feature_extraction import DictVectorizer
import pandas as pd
import pandas.core.algorithms as algos
from pandas import Series
import numpy as np


def one_hot_dataframe(data, cols, replace=False):
    vec = DictVectorizer()
    mkdict = lambda row: dict((col, row[col]) for col in cols)
    vecData = pd.DataFrame(vec.fit_transform(data[cols].apply(mkdict, axis=1)).toarray())
    vecData.columns = vec.get_feature_names()
    vecData.index = data.index
    if replace is True:
        data = data.drop(cols, axis=1)
        data = data.join(vecData)
    return (data, vecData, vec)

def one_hot_dataframe2(data, cols, replace=False):
    vec = DictVectorizer()
    mkdict = lambda row: dict((col, row[col]) for col in cols)
    vecData = pd.DataFrame(vec.fit_transform(data[cols].apply(mkdict, axis=1)).toarray())
    vecData.columns = vec.get_feature_names()
    vecData.index = data.index
    if replace is True:
        data = data.drop(cols, axis=1)
        data = data.join(vecData)
    return (data, vecData, vec, mkdict)
    
# using code from: http://stackoverflow.com/questions/20158597/how-to-qcut-with-non-unique-bin-edges
def helpFun1 (x, n_bins):
    arr = x.as_matrix()
    mx = np.ma.masked_equal(arr, 0, copy=True)
    bins = algos.quantile(arr[~mx.mask], np.linspace(0, 1, n_bins+1))
    bins = np.insert(bins, 0, 0)
    bins[1] = bins[1]-(bins[1]/2)
    result = pd.tools.tile._bins_to_cuts(arr, bins, include_lowest=True)
    return(result)

# using code from: http://stackoverflow.com/questions/20158597/how-to-qcut-with-non-unique-bin-edges
def helpFun2 (x, n_bins):
    bins = algos.quantile(np.unique(x), np.linspace(0, 1, n_bins))
    result = pd.cut(x, bins = bins, labels = False, include_lowest=True)
    return(result)   